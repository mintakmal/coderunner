import express from 'express';
import cors from 'cors';
import helmet from 'helmet';
import rateLimit from 'express-rate-limit';
import { createServer } from 'http';
import { Server } from 'socket.io';
import { executeCode } from './executor.js';
import { validateRequest } from './middleware/validation.js';
import { initDatabase } from './database/init.js';
import authRoutes from './routes/auth.js';
import snippetRoutes from './routes/snippets.js';
import shareRoutes from './routes/share.js';
import { setupCollaboration } from './collaboration/socket.js';

const app = express();
const server = createServer(app);
const io = new Server(server, {
  cors: {
    origin: process.env.FRONTEND_URL || 'http://localhost:5173',
    methods: ['GET', 'POST']
  }
});

const PORT = process.env.PORT || 3001;

// Initialize database
await initDatabase();

// Security middleware
app.use(helmet());
app.use(cors({
  origin: process.env.FRONTEND_URL || 'http://localhost:5173',
  credentials: true
}));

// Rate limiting
const limiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 minutes
  max: 100, // Increased for authenticated users
  message: {
    error: 'Too many requests from this IP, please try again later.'
  }
});

app.use(limiter);
app.use(express.json({ limit: '1mb' }));

// Health check endpoint
app.get('/health', (req, res) => {
  res.json({ 
    status: 'ok', 
    timestamp: new Date().toISOString(),
    version: '2.0.0',
    features: ['execution', 'auth', 'snippets', 'collaboration', 'sharing']
  });
});

// Routes
app.use('/api/auth', authRoutes);
app.use('/api/snippets', snippetRoutes);
app.use('/api/share', shareRoutes);

// Code execution endpoint
app.post('/api/execute', validateRequest, async (req, res) => {
  try {
    const { language, code, input } = req.body;
    
    console.log(`Executing ${language} code for IP: ${req.ip}`);
    
    const startTime = Date.now();
    const result = await executeCode(language, code, input);
    const executionTime = Date.now() - startTime;
    
    res.json({
      ...result,
      executionTime,
      timestamp: new Date().toISOString()
    });
  } catch (error) {
    console.error('Execution error:', error);
    
    res.status(500).json({
      error: 'Internal server error',
      message: error.message
    });
  }
});

// Setup real-time collaboration
setupCollaboration(io);

// Error handling middleware
app.use((err, req, res, next) => {
  console.error(err.stack);
  res.status(500).json({
    error: 'Something went wrong!',
    message: process.env.NODE_ENV === 'development' ? err.message : 'Internal server error'
  });
});

// 404 handler
app.use('*', (req, res) => {
  res.status(404).json({
    error: 'Not found',
    message: 'The requested resource was not found'
  });
});

server.listen(PORT, () => {
  console.log(`🚀 CodeRunner Pro backend running on port ${PORT}`);
  console.log(`📊 Health check: http://localhost:${PORT}/health`);
  console.log(`🔌 WebSocket server ready for collaboration`);
  console.log(`🔐 Authentication enabled`);
  console.log(`💾 Database initialized`);
});