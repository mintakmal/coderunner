import { spawn } from 'child_process';
import { writeFile, unlink, mkdir } from 'fs/promises';
import { join } from 'path';
import { v4 as uuidv4 } from 'uuid';

const TIMEOUT_MS = 10000; // 10 seconds
const TEMP_DIR = '/tmp/coderunner';

// Language configurations
const LANGUAGE_CONFIGS = {
  python: {
    image: 'coderunner-python',
    filename: 'main.py',
    command: ['python', 'main.py']
  },
  javascript: {
    image: 'coderunner-node',
    filename: 'main.js',
    command: ['node', 'main.js']
  },
  cpp: {
    image: 'coderunner-cpp',
    filename: 'main.cpp',
    command: ['sh', '-c', 'g++ -o main main.cpp && ./main']
  },
  java: {
    image: 'coderunner-java',
    filename: 'Main.java',
    command: ['sh', '-c', 'javac Main.java && java Main']
  },
  go: {
    image: 'coderunner-go',
    filename: 'main.go',
    command: ['go', 'run', 'main.go']
  },
  rust: {
    image: 'coderunner-rust',
    filename: 'main.rs',
    command: ['sh', '-c', 'rustc main.rs && ./main']
  }
};

// Ensure temp directory exists
try {
  await mkdir(TEMP_DIR, { recursive: true });
} catch (error) {
  console.error('Failed to create temp directory:', error);
}

export async function executeCode(language, code, input = '') {
  const config = LANGUAGE_CONFIGS[language];
  if (!config) {
    throw new Error(`Unsupported language: ${language}`);
  }

  const executionId = uuidv4();
  const containerName = `coderunner-${executionId}`;
  const tempDir = join(TEMP_DIR, executionId);
  const codeFile = join(tempDir, config.filename);

  try {
    // Create execution directory
    await mkdir(tempDir, { recursive: true });
    
    // Write code to file
    await writeFile(codeFile, code);

    // Execute code in Docker container
    const result = await runInDocker(
      config.image,
      containerName,
      tempDir,
      config.command,
      input
    );

    return result;
  } catch (error) {
    console.error(`Execution failed for ${language}:`, error);
    throw error;
  } finally {
    // Cleanup
    try {
      await cleanup(containerName, tempDir);
    } catch (cleanupError) {
      console.error('Cleanup failed:', cleanupError);
    }
  }
}

async function runInDocker(imageName, containerName, hostDir, command, input) {
  return new Promise((resolve, reject) => {
    const dockerArgs = [
      'run',
      '--rm',
      '--name', containerName,
      '--memory=128m',
      '--cpus=0.5',
      '--network=none',
      '--user=1000:1000',
      '-v', `${hostDir}:/app`,
      '-w', '/app',
      imageName,
      ...command
    ];

    const dockerProcess = spawn('docker', dockerArgs);
    
    let stdout = '';
    let stderr = '';
    
    // Send input to the process
    if (input) {
      dockerProcess.stdin.write(input);
    }
    dockerProcess.stdin.end();

    dockerProcess.stdout.on('data', (data) => {
      stdout += data.toString();
    });

    dockerProcess.stderr.on('data', (data) => {
      stderr += data.toString();
    });

    // Set timeout
    const timeout = setTimeout(() => {
      dockerProcess.kill('SIGKILL');
      reject(new Error('Execution timeout'));
    }, TIMEOUT_MS);

    dockerProcess.on('close', (code) => {
      clearTimeout(timeout);
      
      resolve({
        stdout: stdout.trim(),
        stderr: stderr.trim(),
        exitCode: code,
        executionTime: TIMEOUT_MS // We don't have precise timing yet
      });
    });

    dockerProcess.on('error', (error) => {
      clearTimeout(timeout);
      reject(new Error(`Docker execution failed: ${error.message}`));
    });
  });
}

async function cleanup(containerName, tempDir) {
  try {
    // Stop container if still running
    spawn('docker', ['stop', containerName], { stdio: 'ignore' });
    
    // Remove temp directory
    spawn('rm', ['-rf', tempDir], { stdio: 'ignore' });
  } catch (error) {
    console.error('Cleanup error:', error);
  }
}