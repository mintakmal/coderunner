export function validateRequest(req, res, next) {
  const { language, code } = req.body;

  // Validate required fields
  if (!language || typeof language !== 'string') {
    return res.status(400).json({
      error: 'Invalid request',
      message: 'Language is required and must be a string'
    });
  }

  if (!code || typeof code !== 'string') {
    return res.status(400).json({
      error: 'Invalid request', 
      message: 'Code is required and must be a string'
    });
  }

  // Validate language support
  const supportedLanguages = ['python', 'javascript', 'cpp', 'java', 'go', 'rust'];
  if (!supportedLanguages.includes(language)) {
    return res.status(400).json({
      error: 'Unsupported language',
      message: `Language '${language}' is not supported. Supported languages: ${supportedLanguages.join(', ')}`
    });
  }

  // Validate code length
  if (code.length > 50000) {
    return res.status(400).json({
      error: 'Code too long',
      message: 'Code must be less than 50,000 characters'
    });
  }

  // Validate input if provided
  if (req.body.input && typeof req.body.input !== 'string') {
    return res.status(400).json({
      error: 'Invalid input',
      message: 'Input must be a string'
    });
  }

  next();
}