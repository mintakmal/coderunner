import express from 'express';
import { db } from '../database/init.js';

const router = express.Router();

// Create shareable link
router.post('/', async (req, res) => {
  try {
    const { language, code, input, title } = req.body;

    if (!language || !code) {
      return res.status(400).json({
        error: 'Missing required fields',
        message: 'Language and code are required'
      });
    }

    const shareId = generateShareId();

    // Store as temporary snippet
    await db.runAsync(
      `INSERT INTO snippets (user_id, title, language, code, input, is_public, share_id)
       VALUES (NULL, ?, ?, ?, ?, TRUE, ?)`,
      [title || 'Shared Snippet', language, code, input || '', shareId]
    );

    res.json({ shareId });
  } catch (error) {
    console.error('Create share error:', error);
    res.status(500).json({
      error: 'Internal server error',
      message: 'Failed to create share link'
    });
  }
});

// Get shared snippet
router.get('/:shareId', async (req, res) => {
  try {
    const { shareId } = req.params;

    const snippet = await db.getAsync(
      `SELECT s.title, s.language, s.code, s.input, s.created_at,
              COALESCE(u.name, 'Anonymous') as author
       FROM snippets s
       LEFT JOIN users u ON s.user_id = u.id
       WHERE s.share_id = ? AND s.is_public = TRUE`,
      [shareId]
    );

    if (!snippet) {
      return res.status(404).json({
        error: 'Snippet not found',
        message: 'The shared snippet does not exist or is no longer available'
      });
    }

    res.json(snippet);
  } catch (error) {
    console.error('Get shared snippet error:', error);
    res.status(500).json({
      error: 'Internal server error',
      message: 'Failed to fetch shared snippet'
    });
  }
});

function generateShareId() {
  return Math.random().toString(36).substring(2, 15) + 
         Math.random().toString(36).substring(2, 15);
}

export default router;