import express from 'express';
import { db } from '../database/init.js';
import { authenticateToken } from './auth.js';

const router = express.Router();

// Get user's snippets
router.get('/', authenticateToken, async (req, res) => {
  try {
    const snippets = await db.allAsync(
      `SELECT id, title, description, language, code, input, is_public, 
              share_id, created_at, updated_at 
       FROM snippets 
       WHERE user_id = ? 
       ORDER BY updated_at DESC`,
      [req.user.userId]
    );

    res.json(snippets);
  } catch (error) {
    console.error('Get snippets error:', error);
    res.status(500).json({
      error: 'Internal server error',
      message: 'Failed to fetch snippets'
    });
  }
});

// Create snippet
router.post('/', authenticateToken, async (req, res) => {
  try {
    const { title, description, language, code, input, isPublic } = req.body;

    if (!title || !language || !code) {
      return res.status(400).json({
        error: 'Missing required fields',
        message: 'Title, language, and code are required'
      });
    }

    const shareId = isPublic ? generateShareId() : null;

    const result = await db.runAsync(
      `INSERT INTO snippets (user_id, title, description, language, code, input, is_public, share_id)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?)`,
      [req.user.userId, title, description, language, code, input || '', isPublic, shareId]
    );

    const snippet = await db.getAsync(
      'SELECT * FROM snippets WHERE id = ?',
      [result.lastID]
    );

    res.status(201).json(snippet);
  } catch (error) {
    console.error('Create snippet error:', error);
    res.status(500).json({
      error: 'Internal server error',
      message: 'Failed to create snippet'
    });
  }
});

// Update snippet
router.put('/:id', authenticateToken, async (req, res) => {
  try {
    const { id } = req.params;
    const { title, description, language, code, input, isPublic } = req.body;

    // Check ownership
    const snippet = await db.getAsync(
      'SELECT user_id FROM snippets WHERE id = ?',
      [id]
    );

    if (!snippet) {
      return res.status(404).json({
        error: 'Snippet not found',
        message: 'The requested snippet does not exist'
      });
    }

    if (snippet.user_id !== req.user.userId) {
      return res.status(403).json({
        error: 'Access denied',
        message: 'You can only update your own snippets'
      });
    }

    const shareId = isPublic ? generateShareId() : null;

    await db.runAsync(
      `UPDATE snippets 
       SET title = ?, description = ?, language = ?, code = ?, input = ?, 
           is_public = ?, share_id = ?, updated_at = CURRENT_TIMESTAMP
       WHERE id = ?`,
      [title, description, language, code, input || '', isPublic, shareId, id]
    );

    const updatedSnippet = await db.getAsync(
      'SELECT * FROM snippets WHERE id = ?',
      [id]
    );

    res.json(updatedSnippet);
  } catch (error) {
    console.error('Update snippet error:', error);
    res.status(500).json({
      error: 'Internal server error',
      message: 'Failed to update snippet'
    });
  }
});

// Delete snippet
router.delete('/:id', authenticateToken, async (req, res) => {
  try {
    const { id } = req.params;

    // Check ownership
    const snippet = await db.getAsync(
      'SELECT user_id FROM snippets WHERE id = ?',
      [id]
    );

    if (!snippet) {
      return res.status(404).json({
        error: 'Snippet not found',
        message: 'The requested snippet does not exist'
      });
    }

    if (snippet.user_id !== req.user.userId) {
      return res.status(403).json({
        error: 'Access denied',
        message: 'You can only delete your own snippets'
      });
    }

    await db.runAsync('DELETE FROM snippets WHERE id = ?', [id]);

    res.json({ message: 'Snippet deleted successfully' });
  } catch (error) {
    console.error('Delete snippet error:', error);
    res.status(500).json({
      error: 'Internal server error',
      message: 'Failed to delete snippet'
    });
  }
});

function generateShareId() {
  return Math.random().toString(36).substring(2, 15) + 
         Math.random().toString(36).substring(2, 15);
}

export default router;