import jwt from 'jsonwebtoken';
import { db } from '../database/init.js';

const JWT_SECRET = process.env.JWT_SECRET || 'your-secret-key';

export function setupCollaboration(io) {
  const rooms = new Map(); // roomId -> { users: Set, code: string, language: string }

  io.use((socket, next) => {
    try {
      const token = socket.handshake.auth.token;
      if (token) {
        const decoded = jwt.verify(token, JWT_SECRET);
        socket.userId = decoded.userId;
        socket.userEmail = decoded.email;
      }
      next();
    } catch (err) {
      // Allow anonymous users for public collaboration
      socket.userId = `anonymous_${Date.now()}`;
      next();
    }
  });

  io.on('connection', (socket) => {
    console.log(`User connected: ${socket.userId}`);

    socket.on('create-room', async (roomId) => {
      try {
        if (!rooms.has(roomId)) {
          rooms.set(roomId, {
            users: new Set(),
            code: '',
            language: 'python',
            owner: socket.userId
          });

          // Store in database if user is authenticated
          if (socket.userId && !socket.userId.startsWith('anonymous_')) {
            await db.runAsync(
              'INSERT INTO collaboration_rooms (room_id, owner_id, language, code) VALUES (?, ?, ?, ?)',
              [roomId, socket.userId, 'python', '']
            );
          }
        }

        socket.join(roomId);
        socket.currentRoom = roomId;
        
        const room = rooms.get(roomId);
        room.users.add({
          id: socket.userId,
          name: socket.userEmail || `User ${socket.userId}`,
          isOwner: socket.userId === room.owner
        });

        // Send current state to new user
        socket.emit('room-joined', {
          roomId,
          code: room.code,
          language: room.language,
          isOwner: socket.userId === room.owner
        });

        // Notify others
        socket.to(roomId).emit('user-joined', {
          id: socket.userId,
          name: socket.userEmail || `User ${socket.userId}`
        });

        // Send updated collaborators list
        io.to(roomId).emit('collaborators-updated', Array.from(room.users));
      } catch (error) {
        console.error('Create room error:', error);
        socket.emit('error', { message: 'Failed to create room' });
      }
    });

    socket.on('join-room', async (roomId) => {
      try {
        if (!rooms.has(roomId)) {
          // Try to load from database
          const dbRoom = await db.getAsync(
            'SELECT * FROM collaboration_rooms WHERE room_id = ? AND is_active = TRUE',
            [roomId]
          );

          if (dbRoom) {
            rooms.set(roomId, {
              users: new Set(),
              code: dbRoom.code,
              language: dbRoom.language,
              owner: dbRoom.owner_id
            });
          } else {
            socket.emit('error', { message: 'Room not found' });
            return;
          }
        }

        socket.join(roomId);
        socket.currentRoom = roomId;
        
        const room = rooms.get(roomId);
        room.users.add({
          id: socket.userId,
          name: socket.userEmail || `User ${socket.userId}`,
          isOwner: socket.userId === room.owner
        });

        // Send current state to new user
        socket.emit('room-joined', {
          roomId,
          code: room.code,
          language: room.language,
          isOwner: socket.userId === room.owner
        });

        // Notify others
        socket.to(roomId).emit('user-joined', {
          id: socket.userId,
          name: socket.userEmail || `User ${socket.userId}`
        });

        // Send updated collaborators list
        io.to(roomId).emit('collaborators-updated', Array.from(room.users));
      } catch (error) {
        console.error('Join room error:', error);
        socket.emit('error', { message: 'Failed to join room' });
      }
    });

    socket.on('code-change', (data) => {
      if (socket.currentRoom && rooms.has(socket.currentRoom)) {
        const room = rooms.get(socket.currentRoom);
        room.code = data.code;
        
        // Broadcast to others in the room
        socket.to(socket.currentRoom).emit('code-updated', {
          code: data.code,
          userId: socket.userId,
          cursor: data.cursor
        });

        // Update database periodically (debounced)
        if (room.updateTimeout) {
          clearTimeout(room.updateTimeout);
        }
        
        room.updateTimeout = setTimeout(async () => {
          try {
            await db.runAsync(
              'UPDATE collaboration_rooms SET code = ?, updated_at = CURRENT_TIMESTAMP WHERE room_id = ?',
              [room.code, socket.currentRoom]
            );
          } catch (error) {
            console.error('Failed to update room in database:', error);
          }
        }, 2000);
      }
    });

    socket.on('language-change', (data) => {
      if (socket.currentRoom && rooms.has(socket.currentRoom)) {
        const room = rooms.get(socket.currentRoom);
        
        // Only owner can change language
        if (socket.userId === room.owner) {
          room.language = data.language;
          io.to(socket.currentRoom).emit('language-updated', {
            language: data.language,
            userId: socket.userId
          });
        }
      }
    });

    socket.on('cursor-change', (data) => {
      if (socket.currentRoom) {
        socket.to(socket.currentRoom).emit('cursor-updated', {
          userId: socket.userId,
          cursor: data.cursor
        });
      }
    });

    socket.on('disconnect', () => {
      console.log(`User disconnected: ${socket.userId}`);
      
      if (socket.currentRoom && rooms.has(socket.currentRoom)) {
        const room = rooms.get(socket.currentRoom);
        room.users = new Set(Array.from(room.users).filter(user => user.id !== socket.userId));
        
        // Notify others
        socket.to(socket.currentRoom).emit('user-left', {
          id: socket.userId
        });

        // Send updated collaborators list
        io.to(socket.currentRoom).emit('collaborators-updated', Array.from(room.users));
        
        // Clean up empty rooms
        if (room.users.size === 0) {
          rooms.delete(socket.currentRoom);
        }
      }
    });
  });
}